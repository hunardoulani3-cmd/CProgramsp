/******************************************************************************

WAPC to input radius and height of a cylinder. Calculate the volume of the cylinder.

*******************************************************************************/
#include <stdio.h>
#define PI 3.142

int main()
{
    float radius , height, volume;
    printf("Enter the radius of the cylinder: ");
    scanf("%f", &radius);
    printf("Enter the height of the cylinder: ");
    scanf("%f", &height);
    volume = radius * radius * height * PI;
    printf("\nVolume of cylinder is: %f",volume);
    return 0;
}