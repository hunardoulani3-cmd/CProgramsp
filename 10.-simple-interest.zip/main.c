/******************************************************************************

WAPC to find the simple interest based on user inputs.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float principal , rate , time , interest ;
    printf("\nEnter the principal: ");
    scanf("%f", &principal);
    
    printf("\nEnter the rate of simple interest: ");
    scanf("%f", &rate);
    
    printf("\nEnter the time in years: ");
    scanf("%f", &time);
    
    interest = (rate * time * principal) / 100.0f;
    printf("\nThe simple interest is Rs. %f", interest);
    return 0;
}