/******************************************************************************

WAPC to find the gender ratio based on the number of males and number of females entered as inputs.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int females, males ; float ratio ;
printf("\nEnter the number of males: ");
scanf("%d", &males);
printf("Enter the number of females: ");
scanf("%d", &females);
ratio = (float) males  / females;
printf("\nThe ratio of number of males to females is %f", ratio);
    return 0;
}
