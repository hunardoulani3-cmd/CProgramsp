/******************************************************************************

WAPC to input the temperature in Celsius and output it in Fahrenheit

*******************************************************************************/
#include <stdio.h>

int main()
{
    float tempc , tempf;
    printf("Enter the temperature: ");
    scanf("%f", &tempc);
    tempf = tempc*1.8 + 32;
    printf("The temperature in fahrenheit is: %f", tempf);
    return 0;
}
