/******************************************************************************

WAPC to check if a triangle is valid or not. If it is valid, check and print if it is isosceles, scalene or equilateral.


*******************************************************************************/
#include <stdio.h>

int main()
{
   unsigned int a, b, c;
   printf("Enter three sides of the triangle ");
   scanf("%u %u %u", &a, &b, &c);
   if(a + b > c && b + c > a && c + a > b && a!=0 && b!=0 && c!=0)
   {
   printf("triangle is valid");
   }
   if(a==b && b==c & c==a)
   {
   printf("\ntriangle is equilateral");
   }
   else if(a==b || b==c || c==a)
   {
   printf("\ntriangle is isosceles");
   }
   else
{
   printf("\ntriangle is scalene");
}
    return 0;
}
