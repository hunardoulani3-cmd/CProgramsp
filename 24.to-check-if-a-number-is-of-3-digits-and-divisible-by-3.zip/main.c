/******************************************************************************

WAPC to check if a number is of 3-digits and divisible by 3.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int num;
    printf("Enter the number: ");
    scanf("%d", &num);
    if(num >= 100 && num <= 999) 
    {
     if(num % 3 == 0)
     {
         printf("\nThe number is divisible by 3");
     }
     else 
     {
         printf("\nThe number is not divisible by 3");
     }
    }
     else 
     {
         printf("\nThe number is not a three digit number");
     }

    return 0;
}
