/******************************************************************************

WAPC to input the number of units of electricity consumed by a consumer. Calculate and print the electricity bill based on the following criteria:
First 100 units: Rs. 2 per unit
Next 200 units: Rs. 3 per unit
Above 300 units: Rs. 4 per unit
A surcharge of 2.5% is levied on the bill if the number of units consumed exceeds 300 units.


*******************************************************************************/
#include <stdio.h>

int main()
{
    int units , bill ; float billAfterSurcharge;
    printf("\nEnter the units of electricity consumed by a consumer: ");
    scanf("%d", &units);
    if(units <= 100)
    {
        bill = units * 2;
        printf("\nThe elecricity bill is Rs. %d",bill);
    }
    else if(units >= 101 && units <= 300)
    {
        bill = 200 + (units-100)*3;
        printf("\nThe elecricity bill is Rs. %d",bill);
    }
    else
    {
        bill = 800 + (units-300)*3;
        billAfterSurcharge = bill * 1.025f;
        printf("\nThe elecricity bill is Rs. %f",billAfterSurcharge);
    }
    return 0;
}   
