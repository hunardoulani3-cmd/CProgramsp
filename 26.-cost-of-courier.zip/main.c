/******************************************************************************

WAPC to accept the weight of a parcel in kilograms and calculate the rate per kilogram based on the following criteria:

First 5 kilograms Rs. 800
Next 5 kilograms Rs. 700
Above 10 kilograms Rs. 500

Also input the type of the courier (‘I’ for International and ‘D’ for Domestic). If the type of the courier is International, an additional amount of Rs. 1500 is levied.


*******************************************************************************/
#include <stdio.h>

int main()
{
    int weight, cost ;
    char type;
    printf("Enter the weight of parcel in kg: ");
    scanf("%d", &weight);
    printf("\nEnter the type of courier(I for international and D for domestic): ");
    scanf(" %c", &type);
    if(weight<=5)
    {
        cost = weight*800;
    }
    else if(weight>5 && weight <=10)
    {
        cost = 4000 + (weight-5)*700;
    }
    else
    {
        cost = 7500 + (weight-10)*500;
    }
    if(type=='I' || type=='i')
    {
      cost += 1500 ;
      printf("\nThe total courier charge is Rs. %d",cost);
    }
    else if(type=='D' || type=='d')
    { 
        cost = cost;
        printf("\nThe total courier charge is Rs. %d",cost);
    }
    else
    {
    printf("Enter the correct type of courier");
    }
    
    return 0;
}