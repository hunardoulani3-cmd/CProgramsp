/******************************************************************************

WAPC to do the following:
Input: account balance, withdrawal amount.
Follow the given rules:
Withdrawal amount must be a multiple of 100.
Withdrawal must not exceed balance.
Maintain a minimum balance of ₹500 after withdrawal.
Output: Transaction success or failure with reason.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int balance, withdraw;
    
    printf("Enter account balance: Rs. ");
    scanf("%d", &balance);
    printf("\nEnter amount to be withdrawn: Rs. ");
    scanf("%d", &withdraw);
    
    if(withdraw % 100 != 0)
    {
        printf("\nThe transaction has failed since withdrawal amount is not a multiple of 100");
    }
    else if(balance<withdraw)
    {
        printf("\nThe transaction has failed since withdrawal amount is more than the balance");
    }
    else if((balance - withdraw) < 500)
    {
        printf("\nThe transaction has failed since balance after withdrawal is less than Rs. 500");
    }
    else
    {
    printf("\nThe transaction is successful");
    }
    return 0;
}
