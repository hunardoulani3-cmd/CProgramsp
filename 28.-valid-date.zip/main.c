/******************************************************************************

WAPC to do the following:
Input: day, month, year.
Check the following:
Month between 1 and 12.
Correct days in month (30 vs 31 days).
February: 28 days normally, 29 days if leap year.
Output: "Valid date" or "Invalid date"

*******************************************************************************/
#include <stdio.h>

int main()
{
   int days, month, year, validDateFlag = 1, leapYearFlag;
   printf("Enter the year: ");
   scanf("%d", &year);
   printf("Enter the month: ");
   scanf(" %d", &month);
   printf("Enter the days: ");
   scanf(" %d", &days);
   if(year%100==0)
   { 
       if(year%400==0)
       {
         leapYearFlag=1;  
       }
       else
       {
           leapYearFlag=0;
       }
   }
   else
   {
       if(year%4==0)
       {
           leapYearFlag=1;
       }
       else
       {
           leapYearFlag=0;
       }
   }
    if(month<1 || month>12)
   {
       validDateFlag=0;
   }
   if(days<1 || days>31)
   { 
       validDateFlag=0; 
   }
   if(year<0)
   {
       validDateFlag=0;    
   }
   if(leapYearFlag==1 && month==2 && days<=29)
   {
       if(days>29)
       { 
           validDateFlag=0;
       }
   }
   if(leapYearFlag==0 && month==2)
   {
       if(days>=29)
       {
        printf("\nInvalid date");
       }
       else if(validDateFlag==1)
       {
           printf("\nValid date");
       }
   }
    return 0;
}
