/******************************************************************************

WAPC to do the following:
Input: age, citizenship status (Y/N), criminal record (Y/N).
Eligible if: age ≥ 18 and citizenship = Y and no criminal record.
If age ≥ 60, print "Senior Citizen Eligible".
If not eligible, specify why.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int age;
    char citizen,criminal;
    printf("Enter age: ");
    scanf("%d", &age);
    printf("\nAre you a citizen (Y/N): ");
    scanf(" %c", &citizen);
    printf("\nDo you have a criminal record (Y/N): ");
    scanf(" %c", &criminal);
    if(age>=18 && citizen=='Y' && criminal=='N')
    {
        if(age>=60)
        {
        printf("\nSenior Citizen Eligibility");
        }
        else
        {
        printf("\nVoter is Eligible");
        }
    }
    else if(age<18 && citizen=='Y' && criminal=='N')
    {
        printf("\nUnderage and so, not eligible");
    }
    else if(age>=18 && criminal=='N' && citizen=='N')
    {
        printf("\nNot a citizen so, not eligible");
    }
    else if(age>=18 && citizen=='Y' && criminal=='Y')
    {
        printf("\nCriminal, not eligible");
    }
    return 0;
}
