/******************************************************************************

WAPC to input five integers from the user. Calculate and print the average.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n1,n2,n3,n4,n5; float average;
    printf("Enter the five integers : ");
    scanf("%d %d %d %d %d", &n1, &n2, &n3, &n4, &n5);
    average = (n1+n2+n3+n4+n5)/5.0f;
    printf("\nThe average of the numbers: %f",average);
    return 0;
}
