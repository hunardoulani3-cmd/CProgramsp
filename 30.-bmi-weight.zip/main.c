/******************************************************************************

WAPC to do the following:
Input: height (m), weight (kg).
Calculate BMI = weight / (height²).
Classify:
BMI < 18.5 → Underweight
18.5 ≤ BMI < 25 → Normal
25 ≤ BMI < 30 → Overweight
≥ 30 → Obese
If overweight or obese and age > 40 → print "Consult doctor".

*******************************************************************************/
#include <stdio.h>

int main()
{
    int weight, age;
    float height, BMI;
    printf("\nEnter the height in metres: ");
    scanf("%f", &height);
    printf("\nEnter the weight in kg: ");
    scanf(" %d", &weight);
    printf("\nEnter the age: ");
    scanf(" %d", &age);
    BMI = weight / (height*height);
    printf("\nBMI = %0.2f", BMI );
    if(age>40 && BMI>=25)
    {
        printf("\nConsult Doctor");
    }
    else if(BMI<18.5)
    {
        printf("\nUnderweight");
    }
    else if(BMI>=18.5 && BMI<25)
    {
        printf("\nNormal");
    }
    else if(BMI>=25 && BMI<30)
    {
        printf("\nOverweight");
    }
    else
    {
        printf("\nObese");
    }
    return 0;
}
