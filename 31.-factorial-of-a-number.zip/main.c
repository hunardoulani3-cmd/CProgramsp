/******************************************************************************

WAPC to input a positive integer from the user. Find and display the factorial of the number.


*******************************************************************************/
#include <stdio.h>

int main()
{
    int integer = 1, num, factorial= 1;
    printf("Enter a number: ");
    scanf("%d", &num);
    while(integer<=num)
    {
        factorial=factorial*integer;
        ++integer;
    }
    printf("\nThe factorial of %d is %d", num,factorial);
    return 0;
}