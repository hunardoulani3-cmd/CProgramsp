/******************************************************************************

WAPC to display the first ‘n’ natural numbers where ‘n’ is the user input.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int number, count=1;
    printf("\nEnter the number of natural numbers to be displayed:");
    scanf("%d", &number);
    while(number>=count)
    {
        count+=
        printf("%d",count);
    }
    return 0;
}
