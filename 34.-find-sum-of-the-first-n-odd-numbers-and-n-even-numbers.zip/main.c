/******************************************************************************

WAPC to display the sum of the first ‘n’ odd numbers and the sum of the first ‘n’ even numbers separately. Here, ‘n’ is the user input.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int number, oddSum = 0, evenSum = 0, count ;
    printf("Enter a number: ");
    scanf("%d", &number);
    for(count=1;number>=count;count++)
    {
        
        oddSum=oddSum+(2*count-1);
        evenSum=evenSum+(2*count);
        
    }
    printf("\nThe sum of first n odd numbers is: %d",oddSum);
    printf("\nThe sum of first n even numbers is: %d",evenSum);

    return 0;
}
