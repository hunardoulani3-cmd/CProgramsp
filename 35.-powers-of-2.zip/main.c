/******************************************************************************

WAPC to display the following series of numbers: 1, 2, 4, 8, …, n-terms. Here, ‘n’ is user input.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int number, count=1 , exponent;
    printf("\nEnter the number of terms: ");
    scanf("%d", &number);
    for(exponent=1;exponent<number;exponent++)
    {
      printf("%d,",count);
      count*=2;
    }
    printf("%d",count);

    return 0;
}
