/******************************************************************************

WAPC to input a positive integer from the user. Check and print if the number is palindrome or not. Note: A palindrome number is a number that remains the same when its digits are reversed, for example, 121.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int num, reversed=0, rem , og;
    printf("Enter a positive integer: ");
    scanf("%d",&num);
    og=num;
    while(num>0)
    {
        rem = num % 10;
        reversed=reversed*10+rem;
        num/=10;
    }
    if(og==reversed)
    {
        printf("\nThe number is a palindrome");
    }
    else
    {
        printf("\nThe number is not a palindrome");
    }
    
    return 0;
}