/******************************************************************************

WAPC to input a positive integer. Assume that the number is of 3 digits. Check and print if the number is Armstrong or not. Note: An Armstrong number is a number that is equal to the sum of its own digits each raised to the power of the number of digits, for example, 153 = 1³ + 5³ + 3³

*******************************************************************************/
#include <stdio.h>

int main()
{
   int num, og ,digit, sum=0;
   printf("Enter a 3 digit positive integer: ");
   scanf("%d", &num);
   og=num;
   while(num>0)
   {
       digit= num%10;
       sum = sum + digit*digit*digit;
       num/=10;
   }
   if(og==sum)
   {
       printf("\nThe number is an Armstrong number");
   }
   else
   {
       printf("\nThe number is not an Armstrong number");
   }

    return 0;
}
