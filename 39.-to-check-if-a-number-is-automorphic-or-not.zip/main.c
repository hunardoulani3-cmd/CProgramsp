/******************************************************************************

WAPC to input a positive integer. Check whether it is Automorphic or not. Note: A number whose square ends with the number itself is an Automorphic number. Example: 25² = 625 (ends with 25)

*******************************************************************************/
#include <stdio.h>

int main()
{
    int num, square, temp = 1;

    
    printf("Enter a positive integer: ");
    scanf("%d", &num);

    square = num*num;

    while (temp <= num) 
    {
        temp *= 10;
    }

    if (square % temp == num)
    {
        printf("\n%d is an automorphic number", num);
    }
    else
    {
        printf("\n%d is not an automorphic number", num);
    }
    return 0;
}
