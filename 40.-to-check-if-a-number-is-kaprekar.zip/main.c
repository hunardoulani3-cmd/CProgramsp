/******************************************************************************

WAPC to input a positive integer. Check whether it is Kaprekar or not. Note: Kaprekar Number – A number whose square can be split into two parts that add up to the number itself. Example: 45² = 2025 → 20 + 25 = 45

*******************************************************************************/
#include <stdio.h>

int main()
{
    int num, square, temp=1, leftPart, rightPart;
    
    printf("Enter a positive integer: ");
    scanf("%d", &num);
    
    square = num*num;
    
    while(temp<=num)
    {
       temp = temp*10; 
    }
    rightPart= square % temp;
    leftPart= square / temp;
    
    if(rightPart+leftPart==num)
    {
        printf("\nThe number is a Kaprekar number");
    }
    else
    {
        printf("\nThe number is not a Kaprekar number");
    }

    return 0;
}
