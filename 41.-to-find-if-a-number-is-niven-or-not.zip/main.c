/******************************************************************************

WAPC to input a positive integer. Check whether it is Niven or not. Note: Niven number – A number divisible by the sum of its digits. Example: 18 ÷ (1+8) = 2

*******************************************************************************/
#include <stdio.h>

int main()
{
   int num, sum = 0 , digit, og;
   printf("Enter a positive integer: ");
   scanf("%d",&num);
   og=num;
   while(og > 0)
   {
       digit = og % 10;
       sum += digit;
       og /= 10;
   }
   if(num % sum == 0)
   {
    printf("\nThe number is a niven number");
   }
   else 
   {
    printf("\nThe number is not a niven number");
   }
   return 0;
}