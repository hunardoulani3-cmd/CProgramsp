/******************************************************************************

WAPC to input a positive integer. Check whether the number is Sunny or not. Note: Sunny Number – A number for which the next number is a perfect square. Example: 8 (since 8+1=9 which is 3²)

*******************************************************************************/
#include <stdio.h>

int main()
{
    int num, next, i=1;
    printf("Enter a positive integer: ");
    scanf("%d",&num);
    next=num+1;
    while(i*i<=next)
    {
        if(i*i==next)
        {
            printf("\nThe number is a sunny number");
            return 0;
        }
        i++;
    }
        {
            printf("\nThe number is not a sunny number");
        }

    return 0;
}
