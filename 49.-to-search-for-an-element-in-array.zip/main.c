/******************************************************************************

WAPC to initialize the array with 10 integers of your choice. Input an integer from the user. Check and display whether or not the input entered by the user is present in the array or not. Use the binary search technique (Hint: Make sure the array elements are sorted).

*******************************************************************************/
#include <stdio.h>

int main()
{
   int arr[]={10,12,14,25,60,70,89,90,93,98};
   int mid,left=0,right=9,flag=0;
   int ele;
   printf("Enter element to be searched in array: ");
   scanf("%d",&ele);
   while(left<=right)
   {
        mid=(left+right)/2;
        if(ele==arr[mid])
        {
            flag=1;
            break;
        }
        else if(arr[mid]>ele)
        {
            right=mid-1;
        }
        else if(arr[mid]<ele)
        {
            left=mid+1;
        }
    }
    if(flag==1)
    {
        printf("\nThe element is found in the array");
    }
    else
    {
        printf("\nThe element is not found in the array");
    }
    
    return 0;
}
