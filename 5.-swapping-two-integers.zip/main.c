/******************************************************************************

WAPC to input two integers and display the contents after swapping.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n1, n2;
    printf("Enter two numbers: ");
    scanf("%d %d", &n1, &n2);
    printf("\nNow the first number is %d and the second %d", n2,n1);
    return 0;
}
