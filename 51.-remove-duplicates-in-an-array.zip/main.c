/******************************************************************************

WAPC to input an integer array from the user. Remove all duplicates and display the resultant array.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n, i, j, flag;
    printf("Enter size of the array: ");
    scanf("%d",&n);

    int arr[n];
    printf("Enter elements:\n");
    for(i=0;i<n;i++) 
    {
    scanf("%d",&arr[i]);
    }

    printf("Array after removing duplicates is:\n");
    for(i=0;i<n;i++) 
    {
        flag = 1;
        for(j=0;j<i;j++) 
        {
            if(arr[i]==arr[j]) 
            {
                flag = 0;  
                break;
            }
        }
        if(flag==1)  
            printf("%d ", arr[i]);
    }
    return 0;
}