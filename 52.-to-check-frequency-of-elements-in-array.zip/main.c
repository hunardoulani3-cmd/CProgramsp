/******************************************************************************

WAPC to input an integer array from the user. Display the frequency of every element in the array.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int n, i, j, count, counted;
    printf("Enter size of the array: ");
    scanf("%d",&n);

    int arr[n];
    printf("Enter the elements:\n");
    for(i=0;i<n;i++)
    {
    scanf("%d",&arr[i]);
    }

    printf("\nFrequency of elements is:\n");
    for(i=0;i<n;i++) 
    {
        counted = 0;
        for(j=0;j<i;j++) 
        {
            if(arr[i]==arr[j]) 
            {
                counted = 1;
                break;
            }
        }

        if(counted == 0) 
        {  
            count = 1;
            for(j=i+1;j<n;j++) 
            {
                if(arr[i]==arr[j]) 
                {
                  count++;  
                }
                
            }
            if(count==1)
            {
            printf("%d occurs %d time\n", arr[i], count);
            }
            else
            {
             printf("%d occurs %d times\n", arr[i], count);   
            }
        }
    }
    return 0;
}
