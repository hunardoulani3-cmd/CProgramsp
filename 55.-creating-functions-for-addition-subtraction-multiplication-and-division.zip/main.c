/******************************************************************************

With the help of 4 user-defined functions, design a basic calculator capable of addition, subtraction, multiplication and division

*******************************************************************************/
#include <stdio.h>

   float add ( float a , float b)
   {
     float c;
     c = a + b;
     return c ;
   }
   float sub ( float a , float b)
   {
     float c;
     c = a - b;
     return c ;
   }
   float mult ( float a , float b)
   {
     float c;
     c = a *b;
     return c ;
   }
   float divide ( float a , float b)
   {
     float c;
     c = a/b;
     return c ;
   }
   int main()
   {
       float x,y,p,q,r,s;
        
       printf("Enter two numbers:\n");
       scanf("%f %f",&x,&y);
        p = add(x,y);
        q = sub(x,y);
        r = mult(x,y);
        s = divide(x,y);
       printf("\nWhen %.2f and %.2f are added , sum is %.2f",x,y,p);
       printf("\nWhen %.2f is subtracted from %.2f, difference is %.2f",y,x,q);
       printf("\nWhen they are multiplied , product is %.2f",r);
       printf("\nWhen %.2f is divided by %.2f, quotient is %.2f",x,y,s);
       
       return 0;
       
   }

  

