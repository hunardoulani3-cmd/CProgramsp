/******************************************************************************

WAPC to diplay prime numbers within the range entered by the user.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int begin , end , i , j ;
    printf("Enter the starting of range: ");
    scanf("%d",&begin);
    printf("\nEnter the ending of range: ");
    scanf(" %d",&end);
    printf("\n Prime numbers between the range are: ");
    for(i=begin;i<=end;i++)
    {
        
            for(j=2;j<i;j++)
            {
                if(i%j==0)
                {
                break;
                }
            }
            if(j==i)
            {
               printf("%d ",i);
            }
         
        
    }
    

    return 0;
}
