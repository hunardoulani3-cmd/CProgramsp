/******************************************************************************

Arrange an array in ascending order using bubble sort

*******************************************************************************/
#include <stdio.h>

int main()
{
    int i , j , num=9, temp;
    int arr[]={23,7,9,12,15,-5,2,16,3};
    for(i=0;i<num-1;++i)
    {
        for(j=0;j<num-i-1;++j)
        {
            
            if(arr[j]>arr[j+1])
            {
              temp = arr[j];
              arr[j] = arr[j+1];
              arr[j+1] = temp;
            }
        }
    }
    printf("Rearranged array is ");
    for(i=0;i<num;++i)
    printf( "%d ",arr[i]);
    return 0;
}