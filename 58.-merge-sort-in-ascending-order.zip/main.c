/******************************************************************************

Merge Sort two sorted arrays (in ascending order). 
Assume no elements are repeated.


*******************************************************************************/
#include <stdio.h>

int main()
{
    int i , length1 , j , length2 ,k ;
    printf("Enter the number of elements of the first array: ");
    scanf("%d",&length1);
    int arr1[length1];
    for(i=0;i<length1;i++)
    {
    printf("Enter the element at arr[%d] of first array: ",i);
    scanf(" %d",&arr1[i]);
    }
    printf("Enter the number of elements of the second array: ");
    scanf(" %d",&length2);
    int arr2[length2];
    for(j=0;j<length2;j++)
    {
    printf("Enter the element at arr[%d] of second array: ",j);
    scanf(" %d",&arr2[j]);
    }
    int merged[length1+length2];
    i = 0; j = 0; k = 0;
    while (i < length1 && j < length2)
    {
        if (arr1[i] < arr2[j])
        {
            merged[k] = arr1[i];
            i++;
            k++;
        }
        else
        {
            merged[k] = arr2[j];
            j++;
            k++;
        }
    }

    while (i < length1)
    {
        merged[k++] = arr1[i++];
    }
    while (j < length2)
    {
        merged[k++] = arr2[j++];
    }

    printf("The merged array in ascending order is\n");
    for (i = 0; i < length1 + length2; i++)
    {
        printf("%d ", merged[i]);
    }

    return 0;
}
