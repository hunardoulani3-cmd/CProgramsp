/******************************************************************************

Sorting an array in descending order using selection sort. 

*******************************************************************************/
#include <stdio.h>

int main()
{
    int i , n , j , max , index, temp;
    printf("Enter the number of elements of the array: ");
    scanf("%d",&n);
    int arr[n];
    for(i=0;i<n;i++)
    {
    printf("Enter the element at arr[%d] of array: ",i);
    scanf(" %d",&arr[i]);
    }
    for (i = 0; i < n - 1; i++)
    {
        max = arr[i];
        index = i;

        for (j = i + 1; j < n; j++)
        {
            if (arr[j] > max)
            {
                max = arr[j];
                index = j;
            }
        }

        if (index != i)
        {
            temp = arr[i];
            arr[i] = arr[index];
            arr[index] = temp;
        }
    }
    printf("Array in descending order:\n");
    for (i = 0; i < n ; i++)
    {
        printf("%d ", arr[i]);
    }
    return 0;
}