/******************************************************************************

WAPC to input two numbers and swap them without using a third variable.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n1, n2;
    printf("Enter two numbers: ");
    scanf("%d %d", &n1, &n2);
     n1=  n1 + n2;
     n2=  n1 - n2;
     n1=  n1 - n2;
    printf("\nNow the first number is %d and the second %d", n1,n2);

    return 0;
}
