/******************************************************************************

Sorting an array in ascending order using insertion sort.

*******************************************************************************/
#include <stdio.h>

int main() 
{
    int n ,i=0, key;
    printf("Enter number of elements in the array: ");
    scanf("%d", &n);
    int arr[n];
    printf("Enter %d integers:\n", n);
    for (int i = 0; i < n; i++) 
    {
        scanf("%d", &arr[i]);
    }
    for (int i = 1; i < n; i++) 
    {
        key = arr[i];
        int j = i - 1;
        
        while (j >= 0 && arr[j] > key) 
        {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
    printf("Sorted array in ascending order is:\n");
    for (int i = 0; i < n; i++) 
    {
        printf("%d ", arr[i]);
    }
   

    return 0;
}
