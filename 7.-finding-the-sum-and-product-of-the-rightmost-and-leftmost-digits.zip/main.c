/******************************************************************************

WAPC to input a 4-digit number and find the sum and product of the rightmost and leftmost digits.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int num, rightmostDigit, leftmostDigit ,  sum , product;
    printf("Enter a 4 digit number: ");
    scanf("%d", &num);
    rightmostDigit = num % 10;
    leftmostDigit = num / 1000;
    sum = leftmostDigit + rightmostDigit;
    product = rightmostDigit * leftmostDigit;
    printf("\nThe sum of the rightmost and leftmost digits is: %d", sum);
    printf("\nThe product of the rightmost and leftmost digits is: %d", product);
    return 0;
}
